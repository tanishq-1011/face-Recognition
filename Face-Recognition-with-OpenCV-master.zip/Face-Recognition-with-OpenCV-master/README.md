Face Recognition using OpenCV in Python

Prerequisites
Numpy
OpenCV

Installing
Install Numpy via anaconda: conda install numpy

Install OpenCV via anaconda: conda install -c menpo opencv
